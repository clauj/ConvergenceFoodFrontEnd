import React from 'react'
import styles from './Erro404.module.css';

const Erro404 = () => {
    return (
        <div className={styles.mensagem}>
            <h1>Erro 404</h1>
        </div>
        
    )
}

export default Erro404
