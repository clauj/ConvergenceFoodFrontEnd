import React from 'react'
import Lojas from '../pages/Lojas'

const MinhaConta = () => {
    return (
        <div className={`container`}>
            <h1>Minha Conta</h1>
            <Lojas />
        </div>
    )
}

export default MinhaConta
